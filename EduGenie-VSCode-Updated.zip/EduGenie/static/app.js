const cards = [...document.querySelectorAll('.task-card')];
const form = document.getElementById('study-form');
const promptBox = document.getElementById('prompt');
const label = document.getElementById('prompt-label');
const statusBox = document.getElementById('status');
const resultPanel = document.getElementById('result-panel');
const resultContent = document.getElementById('result-content');
const submit = form.querySelector('.submit-btn');
let selectedTask = 'qa';
const labels = {
  qa: ['YOUR QUESTION', 'For example: Why is the ocean blue?', 'Here’s your answer'],
  explain: ['WHAT WOULD YOU LIKE EXPLAINED?', 'For example: Photosynthesis, in simple words', 'Let’s make it simple'],
  quiz: ['TOPIC OR STUDY MATERIAL', 'Paste notes or enter a topic for a 3-question quiz', 'Time to test your knowledge'],
  summarize: ['YOUR NOTES OR PASSAGE', 'Paste the text you would like summarized', 'The key points'],
  learn: ['WHAT DO YOU WANT TO LEARN?', 'For example: SQL, from beginner to advanced', 'Your learning path']
};
cards.forEach(card => card.addEventListener('click', () => {
  cards.forEach(item => item.classList.remove('active'));
  card.classList.add('active');
  selectedTask = card.dataset.task;
  const [newLabel, placeholder] = labels[selectedTask];
  label.textContent = newLabel;
  promptBox.placeholder = placeholder;
  resultPanel.hidden = true;
  statusBox.hidden = true;
}));
promptBox.addEventListener('input', () => {
  document.getElementById('char-count').textContent = `${promptBox.value.length.toLocaleString()} / 12,000`;
});
function showError(message) {
  statusBox.textContent = message;
  statusBox.className = 'status error';
  statusBox.hidden = false;
}
function displayQuiz(raw) {
  let parsed;
  try {
    const cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    parsed = JSON.parse(cleaned);
  } catch (_) { return false; }
  if (!Array.isArray(parsed) || !parsed.length) return false;
  resultContent.replaceChildren();
  parsed.forEach((item, index) => {
    if (!item.question || !Array.isArray(item.options)) return;
    const card = document.createElement('div');
    card.className = 'quiz-card';
    const question = document.createElement('div');
    question.className = 'quiz-question';
    question.textContent = `${index + 1}. ${item.question}`;
    card.append(question);
    const feedback = document.createElement('div');
    feedback.className = 'quiz-feedback';
    item.options.slice(0, 4).forEach(option => {
      const choice = document.createElement('label');
      choice.className = 'quiz-option';
      const radio = document.createElement('input');
      radio.type = 'radio'; radio.name = `q${index}`;
      radio.addEventListener('change', () => {
        const correct = option === item.answer;
        feedback.className = `quiz-feedback ${correct ? 'correct' : 'wrong'}`;
        feedback.textContent = correct ? `Correct! ${item.explanation || ''}` : `Not quite. The correct answer is: ${item.answer}${item.explanation ? ` — ${item.explanation}` : ''}`;
      });
      const text = document.createElement('span'); text.textContent = option;
      choice.append(radio, text); card.append(choice);
    });
    card.append(feedback); resultContent.append(card);
  });
  return resultContent.childElementCount > 0;
}
form.addEventListener('submit', async event => {
  event.preventDefault();
  const text = promptBox.value.trim();
  if (text.length < 2) { showError('Please enter at least two characters.'); return; }
  statusBox.className = 'status';
  statusBox.textContent = 'Thinking through it… this can take a few seconds.';
  statusBox.hidden = false;
  resultPanel.hidden = true;
  submit.disabled = true;
  try {
    const response = await fetch(`/api/${selectedTask}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ task: selectedTask, text })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'The request could not be completed.');
    const [newLabel] = labels[selectedTask];
    document.getElementById('result-heading').textContent = labels[selectedTask][2];
    resultContent.textContent = '';
    const rendered = selectedTask === 'quiz' && displayQuiz(data.result);
    if (!rendered) resultContent.textContent = data.result;
    resultPanel.hidden = false;
    if (data.demo) {
      statusBox.className = 'status';
      statusBox.textContent = 'Demo mode: this is a sample response. Add your Gemini API key to .env for live, topic-specific answers.';
      statusBox.hidden = false;
    } else {
      statusBox.hidden = true;
    }
  } catch (error) {
    showError(error.message || 'Something went wrong. Please try again.');
  } finally {
    submit.disabled = false;
  }
});
document.getElementById('copy-btn').addEventListener('click', async event => {
  try {
    await navigator.clipboard.writeText(resultContent.innerText);
    event.currentTarget.textContent = 'Copied!';
    setTimeout(() => { event.currentTarget.textContent = 'Copy'; }, 1500);
  } catch (_) { event.currentTarget.textContent = 'Select to copy'; }
});

