@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Creating virtual environment...
  py -3 -m venv .venv
  if errorlevel 1 (echo Python 3.10+ is required. Install Python and try again.& pause & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
 echo.
echo EduGenie is starting at http://127.0.0.1:8000
echo Press Ctrl+C to stop the server.
python -m uvicorn main:app --reload
