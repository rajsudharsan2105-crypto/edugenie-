# EduGenie — Google Gemini powered learning assistant

A small FastAPI + HTML/CSS learning assistant based on the supplied project description. It supports questions, simple explanations, 3-question interactive quizzes, summaries, and step-by-step learning paths.

## Requirements

- Windows, macOS, or Linux
- Python 3.10 or later
- A Google Gemini API key for live AI responses (get one from [Google AI Studio](https://aistudio.google.com/app/apikey)); sample responses work without a key
- Internet access for Gemini and (optionally) the Google Fonts used by the page

## Run in VS Code on Windows

1. Extract the ZIP and open the `EduGenie` folder in VS Code.
2. Install Python 3.10+ and the VS Code Python extension if needed.
3. Double-click `run.bat`, or open the VS Code terminal and run:

   ```powershell
   py -3 -m venv .venv
   .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   Copy-Item .env.example .env
   python -m uvicorn main:app --reload
   ```

4. Open `.env` and paste your key after `GEMINI_API_KEY=`. Save the file and restart the server.
5. Visit <http://127.0.0.1:8000>.

For VS Code debugging, select **Run and Debug → EduGenie (FastAPI)**. The first launch creates `.venv`, installs the packages and creates `.env` automatically. Add your API key for live Gemini responses. Without a key, the app runs with clearly labelled sample responses.

## macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Add your key to .env, then:
python -m uvicorn main:app --reload
```

## API endpoints

- `POST /qa`
- `POST /explain`
- `POST /quiz`
- `POST /summarize`
- `POST /learn/recommendations`

Each request accepts JSON such as `{"task":"qa","text":"Why is the ocean blue?"}`. The browser interface uses the matching `/api/{task}` routes.

## Notes

- Your API key stays in the local `.env` file and is excluded from Git by `.gitignore`. Never share it or commit it.
- Without an API key, EduGenie uses sample responses so you can explore the interface. With Gemini enabled, answers can still be wrong; verify important facts with trusted learning materials.
- Change `GEMINI_MODEL` in `.env` if you want to select another Gemini model available to your API key.

