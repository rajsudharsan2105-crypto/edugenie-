from __future__ import annotations

import os
import json
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from google import genai
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="EduGenie", description="Your friendly AI learning assistant")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

class LearningRequest(BaseModel):
    task: Literal["qa", "explain", "quiz", "summarize", "learn"]
    text: str = Field(min_length=2, max_length=12000)


def ask_gemini(task: str, text: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        # Small sample responses let new users explore the app before configuring Gemini.
        demos = {
            "qa": "The Pacific Ocean is the largest ocean on Earth. It covers more area than all of Earth's land combined.",
            "explain": "Start with the basic definition, notice how each part works, then connect the parts to see the whole picture. Add your Gemini API key for a tailored explanation of the topic you entered.",
            "quiz": json.dumps([{"question": "Which ocean is largest?", "options": ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"], "answer": "Pacific Ocean", "explanation": "The Pacific is the largest ocean."}, {"question": "What mainly causes ocean tides?", "options": ["Lunar gravity", "Clouds", "Volcanoes", "Wind alone"], "answer": "Lunar gravity", "explanation": "The Moon gravitational pull drives most tides."}, {"question": "Which ocean lies between Africa and Australia?", "options": ["Arctic Ocean", "Indian Ocean", "Southern Ocean", "Atlantic Ocean"], "answer": "Indian Ocean", "explanation": "The Indian Ocean lies between Africa and Australia."}]),
            "summarize": "A good summary keeps the central ideas and key facts while removing repetition and extra detail. Add your Gemini API key to summarize the passage you entered.",
            "learn": "1. Beginner — Learn core vocabulary and basic concepts.\n2. Developing — Work through guided examples and short exercises.\n3. Intermediate — Build a small project and solve practical problems.\n4. Advanced — Explore deeper topics, read official documentation, and create a capstone project.\nAdd your Gemini API key for a learning path tailored to your topic.",
        }
        return demos[task]
    prompts = {
        "qa": f"Answer this learner's question clearly and accurately. Keep it concise, explain important terms, and say when uncertain.\n\nQuestion: {text}",
        "explain": f"Explain this topic to a beginner in simple language. Use a short analogy and a few key points where helpful.\n\nTopic: {text}",
        "quiz": f"Create exactly 3 multiple-choice questions based on the material below. Return ONLY a JSON array. Each item must have: question (string), options (array of exactly 4 strings), answer (the exact text of the correct option), explanation (one short sentence). Ensure one correct answer per question.\n\nMaterial:\n{text}",
        "summarize": f"Summarize the following material for a student. Keep the main facts, use plain language and organized bullet points, and do not add claims absent from the source.\n\nMaterial:\n{text}",
        "learn": f"Make a practical learning path for this topic from beginner to advanced. Include an ordered sequence, suggested time for each stage, practice activities, and reputable resource names or links. Adapt it for a self-learner.\n\nTopic: {text}",
    }
    try:
        client = genai.Client(api_key=api_key)
        model = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip() or "gemini-3.8-flash"
        response = client.models.generate_content(model=model, contents=prompts[task])
        if not response.text:
            raise ValueError("The model returned an empty response.")
        return response.text
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gemini could not complete this request. Check your API key, model name, and internet connection. ({type(exc).__name__})") from exc


def result(task: str, text: str) -> dict:
    return {"task": task, "result": ask_gemini(task, text), "demo": not bool(os.getenv("GEMINI_API_KEY", "").strip())}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})

@app.post("/api/{task}")
def process(task: str, payload: LearningRequest):
    if task not in {"qa", "explain", "quiz", "summarize", "learn"} or task != payload.task:
        raise HTTPException(status_code=404, detail="Unknown learning task.")
    return result(task, payload.text)

# Friendly aliases matching the project report's endpoint names.
@app.post("/qa")
def qa(payload: LearningRequest):
    return result("qa", payload.text)

@app.post("/explain")
def explain(payload: LearningRequest):
    return result("explain", payload.text)

@app.post("/quiz")
def quiz(payload: LearningRequest):
    return result("quiz", payload.text)

@app.post("/summarize")
def summarize(payload: LearningRequest):
    return result("summarize", payload.text)

@app.post("/learn/recommendations")
def learn(payload: LearningRequest):
    return result("learn", payload.text)
